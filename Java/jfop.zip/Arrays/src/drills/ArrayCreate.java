package drills;

public class ArrayCreate {

	public static void main(String[] args) {
		// Declare a variable for an array of String objects to hold the name of each weekday.
		// Initialize the variable to hold 7 Strings.
		String[] weekdays;
		
		// Declare a variable to hold letter grades for each of a student's six classes.
		// Initialize the variable to hold 6 chars.
		char grades[];
		
		// Declare a variable to hold the average monthly precipitation for a year.
		// Initialize the variable to have the correct number of double slots.
		double [ ] avgMonthlyPrecip;
		
		// NOTE: as you can see above, whitespace does not matter.
	}

}
