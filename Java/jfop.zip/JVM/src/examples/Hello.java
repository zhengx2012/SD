package examples;

public class Hello {
  public static void main(String[] args) {
    System.out.print("Hello, ");
    if (args.length == 0)
      System.out.println("World!");
    else
      System.out.println(args[0] + "!");
  }
}