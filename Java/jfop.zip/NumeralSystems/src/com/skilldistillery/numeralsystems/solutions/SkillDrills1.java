package com.skilldistillery.numeralsystems.solutions;

public class SkillDrills1 {

  public static void main(String[] args) {
    /* Write out the following decimal numbers in binary:
     * 3: 11
     * 4: 100
     * 7: 111
     * 11: 1011
     * 16: 10000
     * 15: 1111
     * 20: 10100
     * 21: 10101
     */
  }
  
}
