package com.skilldistillery.datatypes.solutions;

public class CharAsInteger {

  public static void main(String[] args) {
    // Declare a char variable and assign it the value 65. 
    // Print it to the screen.
    char val = 65;
    System.out.println(val);
    
    // Use the += operator to add 25 to your variable. 
    // Now print it to the screen.
    val += 25;
    System.out.println(val);
  }

}
