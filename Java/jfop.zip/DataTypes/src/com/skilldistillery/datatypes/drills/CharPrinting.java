package com.skilldistillery.datatypes.drills;

public class CharPrinting {

  public static void main(String[] args) {
    char variable = 'A';
    System.out.println(variable);
    // Add the line System.out.println(variable + 1); to main(). 
    // What is the output?
    // What does the + operator appear to do - i.e. what the + operator's output?
  
  }

}
