package com.skilldistillery.packages.labs;

public class Product {

}
