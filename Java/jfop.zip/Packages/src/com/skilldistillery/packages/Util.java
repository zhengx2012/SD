package com.skilldistillery.packages;

public class Util {
  public static void utilMethod() {}

}
