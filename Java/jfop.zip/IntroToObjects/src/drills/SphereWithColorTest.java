package drills;

public class SphereWithColorTest {

  public static void main(String[] args) {
    // Create several SphereWithColor reference variables
    // and new objects.

    // Initialize each object's color and radius fields.

    // Call displaySphere for each object.

    // Create another SphereWithColor, but do not initialize its fields.
    // Call its displaySphere method. What values do you see?
  }

}
