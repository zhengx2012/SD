package drills;

public class SphereCreation {

  public static void main(String[] args) {
    // Create three Sphere "objects."
    // 1. A baseball, radius 3.7
    // 2. A basketball, radius 12.0
    // 3. Mercury, radius 244 million centimeters
    //    Try writing this as 244_000_000.0 or 244e5

    // Print each object's volume to the screen using System.out.println.

  }

}
