
public class StringOutputSolution {

	public static void main(String[] args) {
		// Examine the code and add what you expect the output to be in each comment.
		// Then run the code.
		
		// Expected: snowball
		System.out.println("snow " + " ball");
		
		// Notice the print() statement.
		// Expected: I could use some space (empty line)(empty line)
		System.out.print("I could use some space\n\n");
		
		int tensVal = 9;
		int onesVal = 3;
		// Expected: Concatenated number is 93
		System.out.println("Concatenated number is " + tensVal + onesVal);
		
		// Expected: 12 is another number
		System.out.println(tensVal + onesVal + " is another number");

	}

}
