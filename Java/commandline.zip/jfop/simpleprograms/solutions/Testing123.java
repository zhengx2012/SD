
public class Testing123 {
    public static void main(String[] args) {
        System.out.println("Testing ...");
        System.out.println("\t... 1 ...");
        System.out.println("\t\t... 2 ...\n");
        System.out.println("\t\t\t... 3 ...\n");

        // ... OR ...

        System.out.println("Testing ...\n\t... 1 ...\n\t\t... 2 ...\n\t\t\t... 3 ...");
    }
}
