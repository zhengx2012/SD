
public class HelloName {
    public static void main(String[] args) {
        System.out.println("Hello, Pat");
    }
}