
public class VariableNamingSolution {

	public static void main(String[] args) {
		//Declare a variable of type int for the distance something (a car, a rocket) traveled.
		int distanceTraveled;
		
		//Declare a variable of type int for the distance between the center of a circle and its edge.
		int radius;
		
		//Declare a variable of type String for a user's full name;
		String fullName;

	}

}
