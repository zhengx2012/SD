
public class Assign {

	public static void main(String[] args) {
		double battingAverage = .345;
		double thisYearBA = battingAverage;
		battingAverage = .362; //reassignment
		
		System.out.println(battingAverage);
		System.out.println(thisYearBA);
		
		// Run the code listed above, which reassigns battingAverage. Does this change thisYearBA?  

	}

}
